package RoseHill;
import java.util.*;
import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import RoseHill.Deed;

public class RHDeleteUser extends HttpServlet{

    /**
     * Interface to RoseHill data base.
     * @author Walid Sibo
     * Date: sept. 2001
     */

    String WEBserver = "";
    Connection con;
    Statement stmt;
    ResultSet rs;
    PrintWriter os;
    String unicID = "";
    String url = Deed.url;
    String url2 = Deed.url2;
    String key = "rosehillKey";

    String secretKey="Absrcht123567663yteuuii7663kfre456aiehhskllj"+
	"76654498776665qweiur3ioojjneklllelllllllq4qqqq477787999999"+
	"99999999999999874873688773139999999999999qqeuuroooeoouuryeioo"+
	"3oowooooeu4eiiiiroooooooooooooo";

    public void doGet(HttpServletRequest req, 
		      HttpServletResponse res) 
	throws ServletException, IOException{

	String username = "", password = "", username2="";
	res.setContentType("text/html");
	PrintWriter out = res.getWriter();
	HttpSession session = req.getSession(true);
	Hashtable hash = (Hashtable) session.getValue("RoseHill.dbase");

	if(hash == null){
	    //  System.err.println("hash is null");
	    sendError(out, "Unauthorized User");
	    out.close();
	    return;
	}
	else{
	    String skey = (String) hash.get(key);
	    //  System.err.println("in delete skey="+skey);
	    if(!skey.equals(secretKey)){
	    sendError(out, "Unauthorized User");
	    out.close();
	    return;
	    }
	}

	out.println("<HTML><HEAD><TITLE>Delete a User from RoseHill "+
		    "Authorized Users</TITLE>");
	out.println("<script language=Javascript>");
	out.println("  function submit1(){ ");
	out.println("	  if(document.useridForm.useridField.value.length() "+
		    " == 0 && document.useridForm.lst.value.length() == 0){;");
	out.println("    alert(\" No user name entered or selected yet\");");
	out.println("	 return false;   ");
	out.println("		 }       ");
	out.println("	 return true;    ");
	out.println("  }                 ");
	out.println("</script>");
	out.println("</HEAD><BODY onload=\"document.useridForm."+
		    "useridField.focus();\">");
	out.println("<center><h2> Delete a User from Authorized "+
		    "RoseHill Users</h2>");
	out.println("<center><h3> Enter/Select the user name for the user "+
		    "and then press return.</h3>");

	out.println("<FORM NAME=\"useridForm\" 	method=\"post\" "
		      +" onSubmit=\"return submit1()\"> ");
	out.println("<table border=0><tr><td>Username</td><td><INPUT "+
		    "NAME=\"useridField\" TYPE=text></td></tr></table>");
	databaseConnect();

	out.println("<table border=0><tr><td>List of Current Users</td></tr></table>");
	out.println("<select name=lst size=5>" + getUsers(out) + "</select>");
	out.println("<table border=0><tr><td><input type=button value=\"Delete\" onClick=useridForm.submit()> </td></tr></table>");   
	databaseDisconnect();   

	out.println(" </FORM>");
   	out.println("</BODY></HTML>");
	out.close();

    }				   
		  
    public void doPost(HttpServletRequest req, 
		       HttpServletResponse res) 
	throws ServletException, IOException{
	
	res.setStatus(HttpServletResponse.SC_OK);
	res.setContentType("text/html");
	String username = "", password = "", username2="";
	os=res.getWriter();
	Enumeration values = req.getParameterNames();
	String name, value;
	//obtainProperties(os);
	os.println("<html>");

	HttpSession session = req.getSession(true);
	Hashtable hash = (Hashtable) session.getValue("RoseHill.dbase");
	if(hash == null){
	    sendError(os, "Delete user failed, Unauthorized User");
	    os.close();
	    return;
	}
	else{
	    String skey = (String) hash.get(key);
	    // System.err.println("skey="+skey);
	    if(!skey.equals(secretKey)){
		sendError(os, "Delete user failed, Unauthorized User");
		os.close();
		return;
	    }
	}
	while (values.hasMoreElements()){
	    name = ((String)values.nextElement()).trim();
	    value = (req.getParameter(name)).trim();
	    if (name.equals("useridField")){
		username = value.toLowerCase();
	    }
	    if (name.equals("lst")){
		username2 = value.toLowerCase();
	    }
	}
	if(username.equals("")) username = username2;
	try {
	    //
	    // delete the user to the data base
	    //
	    databaseConnect();

	    stmt.executeUpdate("delete from rosehill_authorized "+
				   " where userid='"+username+"'");
	    databaseDisconnect();
	    os.println("<HTML><HEAD><TITLE>User "+username+" deleted from "+
		       "RoseHill "+
		    "Authorized Users</TITLE>");
	    os.println("<center><H2>User "+username+" deleted from "+
		       "Authorized Users Successfully</h2>");

	    os.println("<body>");
	    os.println("<FORM >");
	    os.println("<br>");
	    os.println("<center><table border=0><tr><td><LI>To Delete "+
		       "Another User </td><td><INPUT "+
		       "NAME=\"submit\" TYPE=button Value=\"Click Here\" "+
		       "onclick=\"document.location='"+url+
		       "RHDeleteUser'\">"+
		       "</td></tr>");
	    os.println("<tr><td><LI> Go back to main menu </td> <td> "+
			"<INPUT NAME=\"back\" TYPE=button Value="+
		       "\"Click Here\" "+
			"onclick=\"document.location='"+url2+
		       "index.html'\">"+
			"</td></tr><h3>");
	    os.println(" </table></center> </FORM>");	

	    os.println("</body>");
	    os.println("</html>");
	}
    
	catch (Exception ex) {
	    os.println(ex);
	}
	os.flush();
	os.close();
    }
  
    public void databaseConnect() {
	try {
	    Class.forName("oracle.jdbc.driver.OracleDriver");
	    con = DriverManager.
		getConnection("jdbc:oracle:thin:@oracle.city."+
			      "bloomington.in.us:1521:dev", 
			      "myr","developer");
	    stmt = con.createStatement();
	}
	catch (Exception sqle) {
	    sqle.printStackTrace();
	}
    }

    public void databaseDisconnect(){

	try {
	    con.close();
	}
	catch (Exception e){
	    e.printStackTrace();
	}
    }

    final String doubleApostrify(String s){

	StringBuffer apostrophe_safe = new StringBuffer(s);
	int len = s.length();
	int c = 0;
	while (c < len){                           
	    if (apostrophe_safe.charAt(c) == '\''){
		apostrophe_safe.insert(c, '\'');
		c += 2;
		len = apostrophe_safe.length();
	    }
	    else{
		c++;
	    }
	}
	return apostrophe_safe.toString();
    }

    public void obtainProperties(PrintWriter out){

	try {			
	    FileInputStream fis = 
		new FileInputStream(new 
		    File("/usr/local/apache/servlets/RoseHill/"+
			 "rosehill.ini"));
	    Properties pr = new Properties();
	    pr.load(fis);
	    WEBserver = pr.getProperty("WEBserver");
	} catch(Exception ee) { 
	    out.println(ee.toString());
	}
    }

    //
    // Send an error message as an HTML
    //
    void sendError(PrintWriter out, String message)throws IOException{

	out.println("<html>");
	out.println("<head><title>Add User </title></head>");
	out.println("<body>");
        out.println("<h1>Error in login</h1>");
	out.println("<p>"+message+"</p>");
	out.println("</body>");
	out.println("</html>");

    }
  public String getUsers(PrintWriter out){
	String ret = "";
	try {
	    rs = stmt.executeQuery("select * from  rosehill_authorized order by userid");
	    while(rs.next()) {
		ret = ret + "<option>" + rs.getString(1);
	    }
	}catch(Exception e){out.println(e.toString());}
	return ret;
    }

}

